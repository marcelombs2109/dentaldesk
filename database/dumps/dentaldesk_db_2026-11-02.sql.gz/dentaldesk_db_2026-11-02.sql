--
-- PostgreSQL database dump
--

\restrict zaxwrgfEgonldlXZB14vo6dLSNJcqyjxaAgriioRnMLpB9VbBkq8McmaqgWOzIk

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO dentaldesk_user;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO dentaldesk_user;

--
-- Name: citas; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.citas (
    id uuid NOT NULL,
    paciente_id uuid NOT NULL,
    dentista_id uuid NOT NULL,
    consultorio_id uuid NOT NULL,
    fecha date NOT NULL,
    hora_inicio time(0) without time zone NOT NULL,
    hora_fin time(0) without time zone NOT NULL,
    duracion_minutos character varying(255) NOT NULL,
    motivo character varying(255) NOT NULL,
    estado character varying(255) DEFAULT 'pendiente'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT citas_duracion_minutos_check CHECK (((duracion_minutos)::text = ANY ((ARRAY['30'::character varying, '60'::character varying, '90'::character varying, '120'::character varying])::text[]))),
    CONSTRAINT citas_estado_check CHECK (((estado)::text = ANY ((ARRAY['pendiente'::character varying, 'confirmada'::character varying, 'cancelada'::character varying, 'atendida'::character varying])::text[])))
);


ALTER TABLE public.citas OWNER TO dentaldesk_user;

--
-- Name: consultorios; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.consultorios (
    id uuid NOT NULL,
    nombre character varying(255) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.consultorios OWNER TO dentaldesk_user;

--
-- Name: dentistas; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.dentistas (
    id uuid NOT NULL,
    nombre character varying(255) NOT NULL,
    especialidad character varying(255) NOT NULL,
    turno character varying(255) NOT NULL,
    hora_inicio time(0) without time zone NOT NULL,
    hora_fin time(0) without time zone NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT dentistas_turno_check CHECK (((turno)::text = ANY ((ARRAY['manana'::character varying, 'tarde_noche'::character varying, 'libre'::character varying])::text[])))
);


ALTER TABLE public.dentistas OWNER TO dentaldesk_user;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO dentaldesk_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: dentaldesk_user
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO dentaldesk_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dentaldesk_user
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO dentaldesk_user;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO dentaldesk_user;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: dentaldesk_user
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO dentaldesk_user;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dentaldesk_user
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO dentaldesk_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dentaldesk_user
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO dentaldesk_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dentaldesk_user
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: pacientes; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.pacientes (
    id uuid NOT NULL,
    nombre character varying(255) NOT NULL,
    apellido character varying(255) NOT NULL,
    ci character varying(255) NOT NULL,
    telefono_whatsapp character varying(255) NOT NULL,
    email character varying(255),
    fecha_nacimiento date,
    observaciones text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.pacientes OWNER TO dentaldesk_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO dentaldesk_user;

--
-- Name: recordatorios; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.recordatorios (
    id uuid NOT NULL,
    cita_id uuid NOT NULL,
    enviado_en timestamp(0) without time zone,
    estado character varying(255) DEFAULT 'enviado'::character varying NOT NULL,
    respuesta_wa character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT recordatorios_estado_check CHECK (((estado)::text = ANY ((ARRAY['enviado'::character varying, 'confirmado'::character varying, 'rechazado'::character varying, 'sin_respuesta'::character varying])::text[])))
);


ALTER TABLE public.recordatorios OWNER TO dentaldesk_user;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO dentaldesk_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dentaldesk_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    rol character varying(20) DEFAULT 'odontologo'::character varying NOT NULL,
    dentista_id uuid
);


ALTER TABLE public.users OWNER TO dentaldesk_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dentaldesk_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dentaldesk_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dentaldesk_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.cache (key, value, expiration) FROM stdin;
intruso@dentaldesk.test|127.0.0.1:timer	i:1793150417;	1793150417
intruso@dentaldesk.test|127.0.0.1	i:5;	1793150417
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: citas; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.citas (id, paciente_id, dentista_id, consultorio_id, fecha, hora_inicio, hora_fin, duracion_minutos, motivo, estado, created_at, updated_at) FROM stdin;
a30f620f-5fb4-467d-8137-1c323749cca1	a1bdb7b9-4ba7-4923-8c00-9f61a77714db	a0370280-23b1-4055-9f45-def96a54430a	c81649a3-e623-41c2-bab4-dcfae85473af	2026-10-26	09:00:00	09:30:00	30	Extracción	cancelada	2026-10-24 13:57:30	2026-10-27 05:46:19
a1bd7ee7-43f9-47aa-8eed-943f929cd12d	a1bd7e3c-738e-4344-8809-134226c6b496	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	d0d36851-7fd1-45af-a747-afa0a389205c	2026-05-09	18:00:00	18:30:00	30	extraccion	cancelada	2026-05-09 14:48:19	2026-05-09 15:09:07
a314bc3f-d274-4f06-ad04-acc3ec2ad6a3	a1bdb7b9-4ba7-4923-8c00-9f61a77714db	a0370280-23b1-4055-9f45-def96a54430a	d0d36851-7fd1-45af-a747-afa0a389205c	2026-10-27	14:00:00	14:30:00	30	Revisión	pendiente	2026-10-27 05:48:49	2026-10-27 05:49:51
a1bd7ea4-5299-4bd3-a710-c4a479ae15e0	a1bd7e3c-738e-4344-8809-134226c6b496	9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-09	11:30:00	12:00:00	30	extraccion	atendida	2026-05-09 14:47:35	2026-05-09 15:51:36
a1bd96d5-bd4d-4163-85a5-c0db86fbb1ac	a1bd7e3c-738e-4344-8809-134226c6b496	a0370280-23b1-4055-9f45-def96a54430a	d0d36851-7fd1-45af-a747-afa0a389205c	2026-05-09	11:30:00	13:30:00	120	Revision	cancelada	2026-05-09 15:55:14	2026-05-09 15:56:15
a1bd830a-e6e9-4f45-8c15-b41bd4598981	a1bd7e3c-738e-4344-8809-134226c6b496	a0370280-23b1-4055-9f45-def96a54430a	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-09	18:00:00	18:30:00	30	extraccion	cancelada	2026-05-09 14:59:54	2026-05-09 15:56:51
a1bd93e0-f788-404b-bae7-ac66cb667e58	a1bd7e3c-738e-4344-8809-134226c6b496	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-09	19:30:00	20:00:00	30	Limpieza dental	pendiente	2026-05-09 15:46:58	2026-05-09 16:46:14
a1bdaf5c-0610-414a-84f0-a73576d614c9	a1bdae96-6033-4dbc-a946-69cd56efa712	9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e	d0d36851-7fd1-45af-a747-afa0a389205c	2026-05-09	09:00:00	10:00:00	60	Revisión	pendiente	2026-05-09 17:03:49	2026-05-09 17:03:49
a1bdb7da-f191-4416-819f-49a85d550c5d	a1bdb7b9-4ba7-4923-8c00-9f61a77714db	a0370280-23b1-4055-9f45-def96a54430a	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-10	10:00:00	10:30:00	30	Consulta dental	confirmada	2026-05-09 17:27:34	2026-05-09 17:32:26
a1bda9bb-e2ea-4467-b470-2f659d0b81d4	a1bd873f-aab0-4f84-8528-c81265ce7d4d	a0370280-23b1-4055-9f45-def96a54430a	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-10	09:00:00	09:30:00	30	Limpieza dental	atendida	2026-05-09 16:48:05	2026-05-09 18:41:13
a1bd879a-af75-4336-9f5c-7595cd60711e	a1bd873f-aab0-4f84-8528-c81265ce7d4d	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-09	19:00:00	19:30:00	30	Limpieza dental	confirmada	2026-05-09 15:12:39	2026-05-09 18:41:56
a1bdd861-e710-441f-b5e5-fed53fc26730	a1bd873f-aab0-4f84-8528-c81265ce7d4d	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	d0d36851-7fd1-45af-a747-afa0a389205c	2026-05-10	20:00:00	20:30:00	30	Consulta	pendiente	2026-05-09 18:58:31	2026-05-09 18:58:31
a30df6a5-9be5-460c-9cee-b326ae672736	a30df687-155a-4462-963c-09fbfb5a0412	9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e	c81649a3-e623-41c2-bab4-dcfae85473af	2026-10-23	10:00:00	10:30:00	30	Limpieza	pendiente	2026-10-23 21:01:19	2026-10-23 21:03:39
a1bdd697-1865-45c5-add9-4fac412240b6	a1bdd3f4-617a-4f1b-9a02-2794f21462ca	a0370280-23b1-4055-9f45-def96a54430a	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-10	11:00:00	12:00:00	60	Limpieza	confirmada	2026-05-09 18:53:31	2026-10-24 12:36:39
a1bdabb6-a054-4f8d-acb8-6067febd019e	a1bd873f-aab0-4f84-8528-c81265ce7d4d	9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e	c81649a3-e623-41c2-bab4-dcfae85473af	2026-05-10	10:00:00	10:30:00	30	Prueba	cancelada	2026-05-09 16:53:37	2026-10-24 12:38:02
a30f644f-3c02-4218-b5d1-b271972c6a16	a1bdb7b9-4ba7-4923-8c00-9f61a77714db	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	c81649a3-e623-41c2-bab4-dcfae85473af	2026-10-24	15:00:00	15:30:00	30	revisión	pendiente	2026-10-24 14:03:47	2026-10-24 14:03:47
\.


--
-- Data for Name: consultorios; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.consultorios (id, nombre, activo, created_at, updated_at) FROM stdin;
c81649a3-e623-41c2-bab4-dcfae85473af	Consultorio 1	t	2026-05-09 14:29:10	2026-05-09 14:29:10
d0d36851-7fd1-45af-a747-afa0a389205c	Consultorio 2	t	2026-05-09 14:29:10	2026-05-09 14:29:10
\.


--
-- Data for Name: dentistas; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.dentistas (id, nombre, especialidad, turno, hora_inicio, hora_fin, activo, created_at, updated_at) FROM stdin;
9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e	Dr. García	Odontología General	manana	09:00:00	14:00:00	t	2026-05-09 14:29:10	2026-05-09 14:29:10
3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b	Dr. Perez	Odontología General	tarde_noche	14:00:00	22:00:00	t	2026-05-09 14:29:10	2026-05-09 14:29:10
a0370280-23b1-4055-9f45-def96a54430a	Dra. Mayta	Odontología General	libre	09:00:00	22:00:00	t	2026-05-09 14:29:10	2026-05-09 14:29:10
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2026_05_03_101210_create_pacientes_table	1
5	2026_05_03_101211_create_dentistas_table	1
6	2026_05_03_101212_create_consultorios_table	1
7	2026_05_03_101213_create_citas_table	1
8	2026_05_03_101214_create_recordatorios_table	1
9	2026_10_24_120000_agregar_rol_y_dentista_a_users	2
\.


--
-- Data for Name: pacientes; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.pacientes (id, nombre, apellido, ci, telefono_whatsapp, email, fecha_nacimiento, observaciones, created_at, updated_at, deleted_at) FROM stdin;
a1bd873f-aab0-4f84-8528-c81265ce7d4d	Miguel	Perez	6983423	59172084608	\N	\N	alergias	2026-05-09 15:11:39	2026-05-09 15:11:39	\N
a1bd7e3c-738e-4344-8809-134226c6b496	Andres	Gomez	4369239	72084609	andres1@gmail.com	\N	alergias	2026-05-09 14:46:27	2026-05-09 15:29:33	\N
a1bdae96-6033-4dbc-a946-69cd56efa712	Jose	Mendoza	123456	59172084610	jose@gmail.com	2006-01-21	alergia	2026-05-09 17:01:39	2026-05-09 17:02:32	\N
a1bdb7b9-4ba7-4923-8c00-9f61a77714db	Tina	Chambi	76656565	59178814560	fchami@gmail.com	2026-05-09	pruebas	2026-05-09 17:27:12	2026-05-09 17:27:12	\N
a2cb1b12-3834-4d9d-88eb-215d55d3c8d2	Pedro	Rodriguez	4369231	72084608	miguel@perez.com	2026-09-01	\N	2026-09-20 15:22:42	2026-09-20 15:22:42	\N
a30df687-155a-4462-963c-09fbfb5a0412	andres	perez	123445567	7208408	\N	\N	\N	2026-10-23 21:00:59	2026-10-23 21:00:59	\N
a30f34ae-afb4-4f62-9309-6cfcf74dd6b4	Prueba	Evidencia	EV-ANTES-001	59170000001	prueba.evidencia@example.com	\N	\N	2026-10-24 11:50:37	2026-10-24 11:50:39	2026-10-24 11:50:39
a30f45a5-a069-4dc2-b43a-0c2dc10a0b63	Temporal	Borrado	EV-T9-001	59170000009	\N	\N	\N	2026-10-24 12:38:03	2026-10-24 12:38:03	2026-10-24 12:38:03
a1bdd3f4-617a-4f1b-9a02-2794f21462ca	Irene	Mayta	583828171	59174272446	dra.mayta.cmi@gmail.com	\N	\N	2026-05-09 18:46:08	2026-10-24 14:05:59	2026-10-24 14:05:59
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: recordatorios; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.recordatorios (id, cita_id, enviado_en, estado, respuesta_wa, created_at, updated_at) FROM stdin;
a1bda9d6-7682-4be3-b94e-b8335ed1c09c	a1bda9bb-e2ea-4467-b470-2f659d0b81d4	2026-05-09 16:48:22	confirmado	Si	2026-05-09 16:48:22	2026-05-09 16:50:43
a1bdac3a-2667-4c6a-8594-d9100302f408	a1bdabb6-a054-4f8d-acb8-6067febd019e	2026-05-09 16:55:03	rechazado	No	2026-05-09 16:55:03	2026-05-09 16:55:37
a1bdb807-0b0d-4e25-a5f9-66c77aa34278	a1bdb7da-f191-4416-819f-49a85d550c5d	2026-05-09 17:28:03	confirmado	Si	2026-05-09 17:28:03	2026-05-09 17:32:26
a1bdee6c-7c61-44d6-929a-6ec1b44a788f	a1bdd861-e710-441f-b5e5-fed53fc26730	2026-05-09 20:00:09	enviado	\N	2026-05-09 20:00:09	2026-05-09 20:00:09
a1bdee6a-cfd4-49ed-ba30-58a135da2040	a1bdd697-1865-45c5-add9-4fac412240b6	2026-05-09 20:00:08	confirmado	Sí	2026-05-09 20:00:08	2026-10-24 12:36:39
a310e9d8-080b-44bf-8658-afc70ce55a41	a30f644f-3c02-4218-b5d1-b271972c6a16	2026-10-27 05:45:52	enviado	\N	2026-10-25 08:13:00	2026-10-27 05:45:52
a314bc9d-8a79-48a8-981e-e2d6c4fb4a92	a314bc3f-d274-4f06-ad04-acc3ec2ad6a3	2026-10-27 06:21:20	enviado	\N	2026-10-27 05:49:51	2026-10-27 06:21:20
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
wX2VH5iRoqGwHms91o8tebrOPOe1mWTh319EPGQn	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVpGVkxMNFRyQUdoZnkxTDJtTm8waFZueWxEdlNkVXFDa2l2dENGNyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9kZW50YWxkZXNrLnNpdGlvcy5tYi9sb2dpbiI7fX0=	1793150374
G3ziWAgsBRGiFY2HiL3d8knzghX7acu7YDF4BAjG	2	127.0.0.1	curl/8.5.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMk1GM0RBMTcxNFk2SmE1TEFybmd6TE84T0RWWDdFWHFCWTRTbzBSNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly9kZW50YWxkZXNrLnNpdGlvcy5tYi9wYWNpZW50ZXMvY3JlYXRlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9	1793150042
DKZllVoXkhqXuoLVRhtCoxbtKmoQdmZZX5qbU0dy	2	127.0.0.1	curl/8.5.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMDJMaVFlOEtkOW56VDlHU1MxR0M5SWtDYnlQS2lGOThXZjBzSlBlTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly9kZW50YWxkZXNrLnNpdGlvcy5tYi9wYWNpZW50ZXMvY3JlYXRlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9	1793148524
ct1RPQ0EIyfECjyGQujxTfgvwfOgoCdalsiRnUhQ	5	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQU0yNVR2NkswaUlOd205NFFwVFBNanQ5QW82QTY2TjltTnpCcG52MiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzQ6Imh0dHA6Ly9kZW50YWxkZXNrLnNpdGlvcy5tYi9wYWNpZW50ZXMvYTFiZGI3YjktNGJhNy00OTIzLThjMDAtOWY2MWE3NzcxNGRiIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NTt9	1793150294
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dentaldesk_user
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, rol, dentista_id) FROM stdin;
1	Administrador DentalDesk	admin@dentaldesk.test	\N	$2y$12$EMgQm2Q9Ddl22IYAW.myZeOcLAgyRpYHWhHmvpkO5xWrvra2O1ati	\N	2026-10-24 12:27:51	2026-10-24 12:27:51	administrador	\N
2	Recepcion DentalDesk	recepcion@dentaldesk.test	\N	$2y$12$r7ANdFRUWi3pLHX9.oH0jut06L9i/xlrM5HWHYTjtjotm.ceQdyLm	\N	2026-10-24 12:27:51	2026-10-24 12:27:51	recepcionista	\N
3	Dr. García	garcia@dentaldesk.test	\N	$2y$12$/QQ2AzcnPKUsrWW9OdC2IeaOve4R/mQOQayjN5hiXKAZQyylJz1nC	\N	2026-10-24 12:27:51	2026-10-24 12:27:51	odontologo	9b6c7512-b4a0-4a0f-9f56-119b46b8bc2e
4	Dr. Perez	perez@dentaldesk.test	\N	$2y$12$Zp/.2rSCXtTztw/JPcf/W.6PXVWC4NL4cjZORBiEJr21Rfo0gakcS	\N	2026-10-24 12:27:51	2026-10-24 12:27:51	odontologo	3dae9676-f5e6-4e3f-9d37-f1f1f9b8799b
5	Dra. Mayta	mayta@dentaldesk.test	\N	$2y$12$n4EKNp/zqI46ilVAcf3Bruxyatrov16DYiZWC7aLZZqo7wwOKGkBa	U8rgAGf8LxRKFL7bhzRMSj9cBz8KHipAa1ajN3Uc5f18kmNHcCk78zxIJuj6	2026-10-24 12:27:52	2026-10-24 12:27:52	odontologo	a0370280-23b1-4055-9f45-def96a54430a
\.


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dentaldesk_user
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dentaldesk_user
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dentaldesk_user
--

SELECT pg_catalog.setval('public.migrations_id_seq', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dentaldesk_user
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: citas citas_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.citas
    ADD CONSTRAINT citas_pkey PRIMARY KEY (id);


--
-- Name: consultorios consultorios_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.consultorios
    ADD CONSTRAINT consultorios_pkey PRIMARY KEY (id);


--
-- Name: dentistas dentistas_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.dentistas
    ADD CONSTRAINT dentistas_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: pacientes pacientes_ci_unique; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_ci_unique UNIQUE (ci);


--
-- Name: pacientes pacientes_email_unique; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_email_unique UNIQUE (email);


--
-- Name: pacientes pacientes_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: recordatorios recordatorios_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.recordatorios
    ADD CONSTRAINT recordatorios_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: dentaldesk_user
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: dentaldesk_user
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: dentaldesk_user
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: citas citas_consultorio_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.citas
    ADD CONSTRAINT citas_consultorio_id_foreign FOREIGN KEY (consultorio_id) REFERENCES public.consultorios(id);


--
-- Name: citas citas_dentista_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.citas
    ADD CONSTRAINT citas_dentista_id_foreign FOREIGN KEY (dentista_id) REFERENCES public.dentistas(id);


--
-- Name: citas citas_paciente_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.citas
    ADD CONSTRAINT citas_paciente_id_foreign FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id);


--
-- Name: recordatorios recordatorios_cita_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.recordatorios
    ADD CONSTRAINT recordatorios_cita_id_foreign FOREIGN KEY (cita_id) REFERENCES public.citas(id);


--
-- Name: users users_dentista_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dentaldesk_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dentista_id_foreign FOREIGN KEY (dentista_id) REFERENCES public.dentistas(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict zaxwrgfEgonldlXZB14vo6dLSNJcqyjxaAgriioRnMLpB9VbBkq8McmaqgWOzIk

